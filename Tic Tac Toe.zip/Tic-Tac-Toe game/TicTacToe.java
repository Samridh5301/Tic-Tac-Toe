import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class TicTacToe{
	static Panel menuBar,BoardPanel,EastPanel,WestPanel;
	static Button b1,b2,b3,b4,b5,b6,b7,b8,b9,replay;
	static TextField chanceWinsdisplay;
	static int chance = 1;
	static String WinerName;
	static String []label = new String[9];
	static boolean isWinner;
	
	public static void main(String []args){
		//doing work related to Frame
		Frame frame = new Frame("TicTacToe");
		frame.setVisible(true);
		frame.setLayout(new BorderLayout());
		frame.setSize(500,500);
		frame.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
		
		
		//doing all work related to menuBar and sidePANELS
		Color c = new Color(0-162-232);
		
		menuBar = new Panel();
		menuBar.setLayout(new FlowLayout());
		
		EastPanel = new Panel();
		WestPanel=new Panel();
		
		
		
		chanceWinsdisplay = new TextField();
		chanceWinsdisplay.setEditable(false);
		chanceWinsdisplay.setBackground(c);
		chanceWinsdisplay.setText("O's turn");
		menuBar.add(chanceWinsdisplay);
		
		
		
		frame.add(menuBar, BorderLayout.NORTH);
		frame.add(EastPanel, BorderLayout.EAST);
		frame.add(WestPanel, BorderLayout.WEST);
		
		//initailising Buttons
		b1 = new Button("  ");
		b2 = new Button("  ");
		b3 = new Button("  ");
		b4 = new Button("  ");
		b5 = new Button("  ");
		b6 = new Button("  ");
		b7 = new Button("  ");
		b8 = new Button("  ");
		b9 = new Button("  ");
		
		//doing all work related to BoardPanel
		BoardPanel = new Panel();
		BoardPanel.setLayout(new GridLayout(3,3,1,1));
		
		BoardPanel.add(b1);
		BoardPanel.add(b2);
		BoardPanel.add(b3);
		BoardPanel.add(b4);
		BoardPanel.add(b5);
		BoardPanel.add(b6);
		BoardPanel.add(b7);
		BoardPanel.add(b8);
		BoardPanel.add(b9);
		
		frame.add(BoardPanel,BorderLayout.CENTER);
		
		backendCode();
		
	}
	
	public static void checkWin(){
		label[0]=b1.getLabel();
		label[1]=b2.getLabel();
		label[2]=b3.getLabel();
		label[3]=b4.getLabel();
		label[4]=b5.getLabel();
		label[5]=b6.getLabel();
		label[6]=b7.getLabel();
		label[7]=b8.getLabel();
		label[8]=b9.getLabel();
		
		//showing chance of the player:
		if(chance<2 || chance%2!=0){
			chanceWinsdisplay.setText("O's turn");
		}else{
			chanceWinsdisplay.setText("X's turn");
		}
		
		//checking for winner or it's a draw:--
		
		if( label[0] == "O" && label[1] == "O" && label[2] == "O" ){//starting with O's
			chanceWinsdisplay.setText("O WINS");
			b1.setBackground(Color.GREEN);
			b2.setBackground(Color.GREEN);
			b3.setBackground(Color.GREEN);
			isWinner = true;
			
		}else if(label[3] == "O" && label[4] == "O" && label[5] == "O"){
			chanceWinsdisplay.setText("O WINS");
			b4.setBackground(Color.GREEN);
			b5.setBackground(Color.GREEN);
			b6.setBackground(Color.GREEN);
			isWinner = true;
		}else if(label[6] == "O" && label[7] == "O" && label[8] == "O"){
			chanceWinsdisplay.setText("O WINS");
			b7.setBackground(Color.GREEN);
			b8.setBackground(Color.GREEN);
			b9.setBackground(Color.GREEN);
			isWinner = true;
		}else if(label[0] == "O" && label[4] == "O" && label[8] == "O"){
			chanceWinsdisplay.setText("O WINS");
			b1.setBackground(Color.GREEN);
			b5.setBackground(Color.GREEN);
			b9.setBackground(Color.GREEN);
			isWinner = true;
		}else if(label[2] == "O" && label[4] == "O" && label[6] == "O"){
			chanceWinsdisplay.setText("O WINS");
			b3.setBackground(Color.GREEN);
			b5.setBackground(Color.GREEN);
			b7.setBackground(Color.GREEN);
			isWinner = true;
		}else if( label[0] == "X" && label[1] == "X" && label[2] == "X" ){//starting with X's
			chanceWinsdisplay.setText("X WINS");
			b1.setBackground(Color.GREEN);
			b2.setBackground(Color.GREEN);
			b3.setBackground(Color.GREEN);
			isWinner = true;
			
		} else if( label[3] == "X" && label[4] == "X" && label[5] == "X" ){
			chanceWinsdisplay.setText("X WINS");
			b4.setBackground(Color.GREEN);
			b5.setBackground(Color.GREEN);
			b6.setBackground(Color.GREEN);
			isWinner = true;
			
		} else if( label[6] == "X" && label[7] == "X" && label[8] == "X" ){
			chanceWinsdisplay.setText("X WINS");
			b7.setBackground(Color.GREEN);
			b8.setBackground(Color.GREEN);
			b9.setBackground(Color.GREEN);
			isWinner = true;
			
		}else if(label[0] == "X" && label[4] == "X" && label[8] == "X"){
			chanceWinsdisplay.setText("X WINS");
			b1.setBackground(Color.GREEN);
			b5.setBackground(Color.GREEN);
			b9.setBackground(Color.GREEN);
			isWinner = true;
		}else if(label[2] == "X" && label[4] == "X" && label[6] == "X"){
			chanceWinsdisplay.setText("X WINS");
			b3.setBackground(Color.GREEN);
			b5.setBackground(Color.GREEN);
			b7.setBackground(Color.GREEN);
			isWinner = true;
		}else if(chance == 10 && isWinner == false){
			chanceWinsdisplay.setText("Draw");
		}else if(label[0] == "O" && label[3] == "O" && label[6] == "O" ){
			b1.setBackground(Color.GREEN);
			b4.setBackground(Color.GREEN);
			b7.setBackground(Color.GREEN);
			isWinner = true;
			chanceWinsdisplay.setText("O WINS");
		}else if(label[1] == "O" && label[4] == "O" && label[7] == "O" ){
			b2.setBackground(Color.GREEN);
			b5.setBackground(Color.GREEN);
			b8.setBackground(Color.GREEN);
			isWinner = true;
			chanceWinsdisplay.setText("O WINS");
		}else if(label[2] == "O" && label[5] == "O" && label[8] == "O" ){
			b3.setBackground(Color.GREEN);
			b6.setBackground(Color.GREEN);
			b9.setBackground(Color.GREEN);
			isWinner = true;
			chanceWinsdisplay.setText("O WINS");
		}else if(label[1] == "X" && label[4] == "X" && label[7] == "X" ){
			b2.setBackground(Color.GREEN);
			b5.setBackground(Color.GREEN);
			b8.setBackground(Color.GREEN);
			isWinner = true;
			chanceWinsdisplay.setText("X WINS");
		}else if(label[1] == "X" && label[4] == "X" && label[7] == "X" ){
			b2.setBackground(Color.GREEN);
			b5.setBackground(Color.GREEN);
			b8.setBackground(Color.GREEN);
			isWinner = true;
			chanceWinsdisplay.setText("X WINS");
		}else if(label[2] == "X" && label[5] == "X" && label[8] == "X" ){
			b3.setBackground(Color.GREEN);
			b6.setBackground(Color.GREEN);
			b9.setBackground(Color.GREEN);
			isWinner = true;
			chanceWinsdisplay.setText("X WINS");
		}
	}
	
	public static void backendCode(){
		
		
		
		
		//adding actionListners to b1:
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				label[0] = b1.getLabel();
				
				if(label[0] == "O" || label[0] == "X" || isWinner == true){
					
				}else{
					if(chance<2 || chance%2!=0){
						chance++;
						b1.setLabel("O");
						checkWin();
					}else{
						chance++;
						b1.setLabel("X");
						checkWin();
					}
				}
			}
		});
		
		//adding actionListners to b2:-
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				label[1] = b2.getLabel();
				
				if(label[1] == "O" || label[1] == "X" || isWinner == true){
					
				}else{
					if(chance<2 || chance%2!=0){
						chance++;
						b2.setLabel("O");
						checkWin();
					}else{
						chance++;
						b2.setLabel("X");
						checkWin();
					}
				}
			}
		});
		
		//adding actionListners to b3:-
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				label[2] = b3.getLabel();
				
				if(label[2] == "O" || label[2] == "X" || isWinner == true){
					
				}else{
					if(chance<2 || chance%2!=0){
						chance++;
						b3.setLabel("O");
						checkWin();
					}else{
						chance++;
						b3.setLabel("X");
						checkWin();
					}
				}
			}
		});
		
		//adding actionListners to b4:-
		b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				label[3] = b4.getLabel();
				
				if(label[3] == "O" || label[3] == "X" || isWinner == true){
					
				}else{
					if(chance<2 || chance%2!=0){
						chance++;
						b4.setLabel("O");
						checkWin();
					}else{
						chance++;
						b4.setLabel("X");
						checkWin();
					}
				}
			}
		});
		
		//adding actionListners to b5:-
		b5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				label[4] = b5.getLabel();
				
				if(label[4] == "O" || label[4] == "X" || isWinner == true){
					
				}else{
					if(chance<2 || chance%2!=0){
						chance++;
						b5.setLabel("O");
						checkWin();
					}else{
						chance++;
						b5.setLabel("X");
						checkWin();
					}
				}
			}
		});
		
		//adding actionListners to b6:-
		b6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				label[5] = b6.getLabel();
				
				if(label[5] == "O" || label[5] == "X" || isWinner == true){
					
				}else{
					if(chance<2 || chance%2!=0){
						chance++;
						b6.setLabel("O");
						checkWin();
					}else{
						chance++;
						b6.setLabel("X");
						checkWin();
					}
				}
			}
		});
		
		b7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				label[6] = b7.getLabel();
				
				if(label[6] == "O" || label[6] == "X" || isWinner == true){
					
				}else{
					if(chance<2 || chance%2!=0){
						chance++;
						b7.setLabel("O");
						checkWin();
					}else{
						chance++;
						b7.setLabel("X");
						checkWin();
					}
				}
			}
		});
		
		b8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				label[7] = b8.getLabel();
				
				if(label[7] == "O" || label[7] == "X" || isWinner == true){
					
				}else{
					if(chance<2 || chance%2!=0){
						chance++;
						b8.setLabel("O");
						checkWin();
					}else{
						chance++;
						b8.setLabel("X");
						checkWin();
					}
				}
			}
		});
		
		b9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				label[8] = b9.getLabel();
				
				if(label[8] == "O" || label[8] == "X" || isWinner == true){
					
				}else{
					if(chance<2 || chance%2!=0){
						chance++;
						b9.setLabel("O");
						checkWin();
					}else{
						chance++;
						b9.setLabel("X");
						checkWin();
					}
				}
			}
		});
		
	}
}

