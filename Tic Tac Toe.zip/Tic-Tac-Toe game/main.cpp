#include <bits/stdc++.h>
#include<conio.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
int main() {
	system("cls");
	system("title Launcher");
	cout << "_______________________________________________________________________WELCOME TO TIC TAC TOE LAUNCHER__________________________________________________________________\n";
	cout << "                                                                       ENTER 0 TO START:"<<endl;
	cout << "                                                                       ENTER 4 TO EXIT:"<<" ";
	
	int a = getch();
	
	if(a == 48){
		system("java TicTacToe.java");
		main();
	}else{
		system("exit");
	}
	
	return 0;
}